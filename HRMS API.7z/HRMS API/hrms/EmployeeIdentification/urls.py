from django.urls import path
from . import views

urlpatterns = [
    path('api/EmployeeOnboard/',views.EmployeeOnboardRegister.as_view())
]