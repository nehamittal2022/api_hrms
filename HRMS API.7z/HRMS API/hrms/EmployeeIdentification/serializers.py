from rest_framework import serializers
from .serializers import *

# class EmployeeOnboardSerializer(serializers.serializerserializer):
#     class Meta:
#         model = Employee
#         fields = "__all__"


class EmployeeOnboardSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    password = serializers.CharField(max_length=100)
